import React from 'react';

export default class Form extends React.Component {
	state = {
		address_oracle: "",
		address_borrower: "",
		btyes32_currency: "",
		uint256_amount: "",
		uint256_interestRate: "",
		uint256_penaltyInterestRate: "",
		uint256_duesIn: "",
		uint256_firstPayment: "",
		uint256_expiration: "",
		string_metadata: "",
		lendify_amount: "",	
		lendify_date: "",
		lendify_address: "",
	};

	change = e => {
		this.setState({
			[e.target.name]: e.target.value
		});
	};

	onSubmit = e => {
		e.preventDefault();
		this.props.onSubmit(this.state);

	};

	render() {
		return (
			<div>
				<form>
					Market Creation
					<br />
					<input 
						name ="address_oracle"
						placeholder='Oracle Address' 
						value={this.state.address_oracle} 
						onChange={e => this.change(e)}
					/>
					<br />
					<input 
						name ="address_borrower"
						placeholder='Borrower' 
						value={this.state.address_borrower} 
						onChange={e => this.change(e)}
					/>
					<br />
					<input 
						name ="btyes32_currency"
						placeholder='Currency' 
						value={this.state.btyes32_currency} 
						onChange={e => this.change(e)}
					/>
					<br />
					<input 
						name ="uint256_amount"
						placeholder='Amount' 
						value={this.state.uint256_amount} 
						onChange={e => this.change(e)}
					/>
					<br />
					<input 
						name ="uint256_interestRate"
						placeholder='Interest Rate' 
						value={this.state.uint256_interestRate} 
						onChange={e => this.change(e)}
					/>
					<br />
					<input 
						name ="uint256_penaltyInterestRate"
						placeholder='Penalty Interest Rate' 
						value={this.state.uint256_penaltyInterestRate} 
						onChange={e => this.change(e)}
					/>
					<br />
					<input 
						name ="uint256_duesIn"
						placeholder='Due Date' 
						value={this.state.uint256_duesIn} 
						onChange={e => this.change(e)}
					/>
					<br />
					<input 
						name ="uint256_firstPayment"
						placeholder='First Payment' 
						value={this.state.uint256_firstPayment} 
						onChange={e => this.change(e)}
					/>
					<br />
					<input 
						name ="uint256_expiration"
						placeholder='Expiration Time' 
						value={this.state.uint256_expiration} 
						onChange={e => this.change(e)}
					/>
					<br />
					<input 
						name ="string_metadata"
						placeholder='Additional Information' 
						value={this.state.string_metadata} 
						onChange={e => this.change(e)}
					/>

					<button onClick={e => this.onSubmit(e)}>Submit</button>

				</form>

				<br />

				<form>
					Lendify Pairing
					<br />
					<input 
						name ="Lendify Amount"
						placeholder='Lendify Amount' 
						value={this.state.lendify_amount} 
						onChange={e => this.change(e)}
					/>
					<br />
					<input 
						name ="Lendify Date"
						placeholder='Lendify Date' 
						value={this.state.lendify_date} 
						onChange={e => this.change(e)}
					/>
					<br />
					<input 
						name ="Lendify Address"
						placeholder='Lendify Address' 
						value={this.state.lendify_address} 
						onChange={e => this.change(e)}
					/>
				</form>

			</div>

		);
	}


}
